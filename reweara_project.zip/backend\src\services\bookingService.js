const mongoose = require('mongoose');
const Booking = require('../models/Booking');
const Outfit = require('../models/Outfit');
const AppError = require('../utils/appError');
const logger = require('../utils/logger');

/**
 * BookingService - Hardened Circular Rental Transaction Lifecycle.
 * Coordinates B-tree date overlap checking, 15m pending holds,
 * sandbox Razorpay order abstractions, and strict RBAC state machines.
 */
class BookingService {
  /**
   * Asserts whether a target outfit is available for a requested rental window.
   * Employs B-tree range scan query indexes for performant scans.
   */
  static async verifyAvailability(outfitId, startDate, endDate, excludeBookingId = null) {
    const requestedStart = new Date(startDate);
    const requestedEnd = new Date(endDate);

    if (isNaN(requestedStart.getTime()) || isNaN(requestedEnd.getTime())) {
      throw new AppError('Invalid query dates provided.', 400);
    }

    if (requestedStart >= requestedEnd) {
      throw new AppError('Rental start date must be strictly before the rental end date.', 400);
    }

    // Overlap Query Parameters Setup
    let query = {
      outfit: outfitId,
      bookingStatus: { $ne: 'cancelled' },
      startDate: { $lte: requestedEnd },
      endDate: { $gte: requestedStart }
    };

    // Exclude the current booking document to prevent self-overlap collisions during payment verification (Bug Fix)
    if (excludeBookingId) {
      query._id = { $ne: excludeBookingId };
    }

    const collision = await Booking.findOne(query).hint('booking_overlap_scan_index');

    return !collision;
  }

  /**
   * Stage 1: Initiates a 15-minute pending hold and generates a mock Razorpay Order object.
   *
   * @param {string} customerId - ObjectID of Customer
   * @param {Object} bookingData - Form inputs
   * @returns {Promise<Object>} - Contains booking details and the mock Razorpay Order
   */
  static async createBookingOrder(customerId, bookingData) {
    const { outfitId, startDate, endDate, adminNotes } = bookingData;

    // 1. Verify target Outfit document exists and is available
    const outfit = await Outfit.findById(outfitId);
    if (!outfit) {
      throw new AppError('The target outfit for this booking order was not found.', 404);
    }

    if (outfit.status !== 'available') {
      throw new AppError('Sorry, this outfit is currently in maintenance or retired from inventory.', 400);
    }

    // 2. Perform availability overlap query scan
    const isAvailable = await this.verifyAvailability(outfitId, startDate, endDate);
    if (!isAvailable) {
      throw new AppError('Sorry, this outfit is no longer available for the selected dates.', 409);
    }

    // 3. Compute duration and pricing snapshots
    const start = new Date(startDate);
    const end = new Date(endDate);
    const differenceInDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24)) || 1;

    const rentPrice = outfit.rentPrice;
    const refundableDeposit = outfit.refundableDeposit;
    const securityDeposit = outfit.refundableDeposit; 
    const totalRentAmount = rentPrice * differenceInDays;

    const pricingSnapshot = {
      rentPrice,
      refundableDeposit,
      securityDeposit
    };

    // Generate unique bookingId
    const bookingId = `BKG-${Date.now().toString().substring(5)}`;
    const reservationExpiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15-minute lock hold

    // 4. Instantiate temporary lock document in collection
    const booking = await Booking.create({
      bookingId,
      customer: customerId,
      outfit: outfitId,
      startDate,
      endDate,
      totalRentAmount,
      securityDeposit,
      refundableDeposit,
      bookingStatus: 'pending',
      paymentStatus: 'pending',
      deliveryStatus: 'pending',
      pricingSnapshot,
      adminNotes: adminNotes || '',
      reservationExpiresAt
    });

    // 5. Generate mock sandbox Razorpay order object (Enforces Correction 3)
    const razorpayOrder = {
      id: `order_mock_${Math.random().toString(36).substring(2, 10)}`,
      amount: totalRentAmount * 100, // Amount in paise
      currency: 'INR',
      receipt: bookingId,
      status: 'created'
    };

    // Bind simulated Razorpay Order ID to the booking document for verification loops
    booking.adminNotes = `Razorpay Order [${razorpayOrder.id}] bound. Awaiting payment capturing.`;
    await booking.save();

    logger.info(`🔒 Temp hold set under Booking [${bookingId}] (Expires in 15m). Razorpay Order [${razorpayOrder.id}] generated.`);
    return {
      booking,
      razorpayOrder
    };
  }

  /**
   * Stage 2: Verifies simulated payment callbacks and transitions pending locks to confirmed.
   *
   * @param {string} bookingId - Target custom bookingId
   * @param {Object} paymentData - Contains simulated payment IDs and signature
   * @returns {Promise<Object>} - Confirmed booking document
   */
  static async verifyPaymentSignature(bookingId, paymentData) {
    const { razorpayPaymentId, signature, status } = paymentData;

    const booking = await Booking.findOne({ bookingId });
    if (!booking) {
      throw new AppError('Verification failed: Reservation record not found.', 404);
    }

    if (booking.bookingStatus !== 'pending') {
      throw new AppError(`Verification failed: Booking is in status [${booking.bookingStatus}] and cannot capture payments.`, 400);
    }

    // Capture simulated payment capture failures safely (Preserves audit logs)
    if (status === 'failed') {
      booking.bookingStatus = 'cancelled';
      booking.paymentStatus = 'failed';
      booking.cancellationReason = 'Simulated checkout payment capture failed.';
      booking.reservationExpiresAt = undefined; // Enforce TTL safety to keep record for audit!
      await booking.save();

      logger.warn(`❌ PAYMENT FAILED: Booking [${bookingId}] transitioned to cancelled. Audit log preserved.`);
      return booking;
    }

    // Stage 2 overlap collision check (guards against parallel checkout race conditions)
    // Pass booking._id as the excludeBookingId to prevent self-overlap collisions
    const isStillAvailable = await this.verifyAvailability(
      booking.outfit,
      booking.startDate,
      booking.endDate,
      booking._id
    );

    if (!isStillAvailable) {
      booking.bookingStatus = 'cancelled';
      booking.paymentStatus = 'failed';
      booking.cancellationReason = 'Concurrency collision detected post-payment. Automated refund queued.';
      booking.reservationExpiresAt = undefined; // Enforce TTL safety
      await booking.save();

      logger.error(`💥 CONCURRENCY COLLISION: Parallel checkout conflict on Booking [${bookingId}]. Refund initialized.`);
      throw new AppError('Date overlap checkout collision resolved post-payment. Transaction cancelled and refunded.', 409);
    }

    // Confirm booking successfully
    booking.bookingStatus = 'confirmed';
    booking.paymentStatus = 'paid';
    booking.cancellationReason = '';
    
    // Bind mock payment IDs
    booking.adminNotes = `Payment verified. Capture ID: ${razorpayPaymentId || 'pay_mock_' + Math.random().toString(36).substring(2, 10)}. Hold cleared.`;
    
    // CRITICAL: Drop TTL holds permanently to secure the active booking document
    booking.reservationExpiresAt = undefined;

    await booking.save();
    logger.success(`🚀 CONFIRMED: Booking [${bookingId}] payment signature captured successfully. Hold cleared.`);
    return booking;
  }

  /**
   * Retrieves historical customer bookings.
   */
  static async getCustomerBookings(customerId) {
    return await Booking.find({ customer: customerId })
      .populate('outfit', 'title slug rentPrice thumbnail status')
      .sort({ createdAt: -1 });
  }

  /**
   * Retrieves detailed booking metadata by ObjectID or custom bookingId string.
   */
  static async getBookingById(identifier) {
    let lookupQuery = {};
    if (mongoose.Types.ObjectId.isValid(identifier)) {
      lookupQuery._id = identifier;
    } else {
      lookupQuery.bookingId = identifier;
    }

    const booking = await Booking.findOne(lookupQuery)
      .populate('customer', 'name email phone role address')
      .populate('outfit', 'title slug rentPrice refundableDeposit thumbnail averageRating status');

    if (!booking) {
      throw new AppError('The requested booking record was not found.', 404);
    }

    return booking;
  }

  /**
   * Cancels a customer booking with audit trail support.
   */
  static async cancelBooking(customerId, bookingId, cancellationReason) {
    const booking = await Booking.findOne({ bookingId });
    if (!booking) {
      throw new AppError('No booking record found with that identifier.', 404);
    }

    if (booking.customer.toString() !== customerId.toString()) {
      throw new AppError('Forbidden: You are not authorized to cancel this booking.', 403);
    }

    // Enforce state transitions: Cancellation only permitted on pending or confirmed bookings
    const allowedTransitions = {
      pending: ['cancelled'],
      confirmed: ['cancelled'],
      active: [],
      completed: [],
      cancelled: [],
      refunded: []
    };

    const currentStatus = booking.bookingStatus;
    if (!allowedTransitions[currentStatus] || !allowedTransitions[currentStatus].includes('cancelled')) {
      throw new AppError(`Cannot cancel booking. Active rentals in status [${currentStatus}] must undergo admin check-in.`, 400);
    }

    // Transition state machines
    booking.bookingStatus = 'cancelled';
    booking.paymentStatus = booking.paymentStatus === 'paid' ? 'refunded' : 'failed';
    booking.cancellationReason = cancellationReason;
    booking.reservationExpiresAt = undefined; // Drop TTL hold

    await booking.save();
    logger.warn(`🚫 Booking [${bookingId}] cancelled successfully. Status transitioned to cancelled. TTL holds dropped.`);
    return booking;
  }

  /**
   * Performs administrative status updates, enforces strict state transitions,
   * synchronizes transactional/logistics metrics, and registers audit trails.
   *
   * @param {string} bookingId - Target custom bookingId or ObjectId
   * @param {Object} updateData - Status payloads
   * @param {string} adminId - ObjectId of the acting administrator
   * @returns {Promise<Object>} - Hardened updated booking document
   */
  static async adminUpdateBookingStatus(bookingId, updateData, adminId = 'system_admin') {
    const booking = await this.getBookingById(bookingId);

    // Enforce strict booking lifecycle state machine transitions (PHASE 5.5B Requirement)
    const allowedTransitions = {
      pending: ['confirmed', 'cancelled'],
      confirmed: ['active', 'cancelled', 'refunded'],
      active: ['completed'],
      completed: ['refunded'],
      cancelled: [], // Terminal State
      refunded: []   // Terminal State
    };

    if (updateData.bookingStatus) {
      const currentStatus = booking.bookingStatus;
      const targetStatus = updateData.bookingStatus.toLowerCase();

      // Check transition legality
      if (currentStatus !== targetStatus) {
        const permitted = allowedTransitions[currentStatus];
        if (!permitted || !permitted.includes(targetStatus)) {
          logger.error(`❌ ILLEGAL STATUS REJECTED: Attempted to transition Booking [${booking.bookingId}] from [${currentStatus}] to [${targetStatus}].`);
          throw new AppError(`Illegal status transition from [${currentStatus}] to [${targetStatus}] is rejected.`, 400);
        }

        booking.bookingStatus = targetStatus;

        // Enforce TTL Safety: Drop locks upon transition to stable records
        if (['confirmed', 'cancelled', 'completed', 'refunded'].includes(booking.bookingStatus)) {
          booking.reservationExpiresAt = undefined;
        }

        // Automatic state synchronization (PHASE 5.5B Requirement 4)
        if (targetStatus === 'confirmed') {
          booking.paymentStatus = 'paid';
        } else if (targetStatus === 'active') {
          booking.deliveryStatus = 'delivered';
          booking.paymentStatus = 'paid';
        } else if (targetStatus === 'completed') {
          booking.deliveryStatus = 'returned';
          booking.paymentStatus = 'paid';
        } else if (targetStatus === 'cancelled') {
          booking.paymentStatus = booking.paymentStatus === 'paid' ? 'refunded' : 'failed';
          booking.deliveryStatus = 'pending';
        } else if (targetStatus === 'refunded') {
          booking.paymentStatus = 'refunded';
        }

        // Recruiter-grade Audit Logging (PHASE 5.5B Requirement 2)
        const timestamp = new Date().toISOString();
        logger.info(`[AUDIT LOG] Status updated | Admin ID: ${adminId} | Booking ID: ${booking.bookingId} | Old Status: ${currentStatus} | New Status: ${targetStatus} | Timestamp: ${timestamp} | Admin Notes: ${updateData.adminNotes || 'None'}`);

        // Persist audit trail in database record for ledger auditing
        const auditTrail = `\n[Audit - ${timestamp}] Status changed from '${currentStatus}' to '${targetStatus}' by Admin '${adminId}'.`;
        booking.adminNotes = booking.adminNotes ? booking.adminNotes + auditTrail : auditTrail.trim();
      }
    }

    // Allow manual overrides if admin explicitly sent them
    if (updateData.paymentStatus) {
      booking.paymentStatus = updateData.paymentStatus.toLowerCase();
    }

    if (updateData.deliveryStatus) {
      booking.deliveryStatus = updateData.deliveryStatus.toLowerCase();
    }

    if (updateData.adminNotes && !updateData.bookingStatus) {
      booking.adminNotes = updateData.adminNotes;
    } else if (updateData.adminNotes && updateData.bookingStatus) {
      // Append any extra admin comments provided in req.body
      booking.adminNotes += ` | Admin Notes: ${updateData.adminNotes}`;
    }

    await booking.save();
    logger.info(`⚙️ Hardened administrative update saved on Booking [${booking.bookingId}]: bookingStatus=${booking.bookingStatus}, paymentStatus=${booking.paymentStatus}, deliveryStatus=${booking.deliveryStatus}`);
    return booking;
  }
}

module.exports = BookingService;
