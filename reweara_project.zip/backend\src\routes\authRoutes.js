const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
const { validateInput } = require('../middleware/validationMiddleware');
const { authLimiter } = require('../middleware/rateLimiter');

// 1. Public Authentication Entrypoints (Guarded under anti-brute rate limits)
router.post('/signup', authLimiter, validateInput('signup'), authController.signup);
router.post('/login', authLimiter, validateInput('login'), authController.login);
router.post('/logout', authController.logout);
router.post('/refresh-token', authController.refreshToken);

// 2. Secured Profile Access Pathways (Guarded under token validations)
router.get('/me/profile', protect, authController.getProfile);

module.exports = router;
