const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const { protect, authorize } = require('../middleware/authMiddleware');
const { validateInput } = require('../middleware/validationMiddleware');

/**
 * ReWeara - Rental Booking Pipeline Routing Configuration
 * Evaluates route mappings top-down. Static routes reside strictly
 * above dynamic wildcard routes to prevent parameter lookup collisions.
 */

// ==========================================
// 1. PUBLIC PATHWAYS
// ==========================================

// Public date conflict checker pipeline
router.post(
  '/check-availability',
  validateInput('check_booking_availability'),
  bookingController.checkAvailability
);

// ==========================================
// 2. SECURED CUSTOMER PATHWAYS (Bearer JWT Guarded)
// ==========================================

// Create a new temporary checkout booking lock (Standard fallback)
router.post(
  '/',
  protect,
  validateInput('create_booking'),
  bookingController.createBooking
);

// Create a new pending hold + sandbox Razorpay order payload (Stage 1)
router.post(
  '/create-order',
  protect,
  validateInput('create_booking'),
  bookingController.createBookingOrder
);

// Verify simulated payment signature and capture bookings (Stage 2)
router.post(
  '/verify-payment',
  protect,
  bookingController.verifyPaymentSignature
);

// Retrieve active authenticated user bookings list
router.get(
  '/my-bookings',
  protect,
  bookingController.getMyBookings
);

// ==========================================
// 3. ADMINISTRATIVE CONTROL PATHWAYS (Guarded under RBAC)
// ==========================================

// Global paginated bookings audit logs
router.get(
  '/admin',
  protect,
  authorize('super_admin', 'admin'),
  bookingController.getAllBookingsAdmin
);

// Update order, payment, and delivery status transitions (Lifecycle Hardened)
router.patch(
  '/admin/:id',
  protect,
  authorize('super_admin', 'admin'),
  validateInput('admin_update_booking'),
  bookingController.updateBookingStatusAdmin
);

// ==========================================
// 4. DYNAMIC WILDCARD PATHWAYS (Reside at bottom to prevent collisions)
// ==========================================

// Fetch detailed booking metadata profile
router.get(
  '/:id',
  protect,
  bookingController.getBookingDetails
);

// Cancel an active booking order
router.patch(
  '/:id/cancel',
  protect,
  validateInput('cancel_booking'),
  bookingController.cancelBooking
);

module.exports = router;
