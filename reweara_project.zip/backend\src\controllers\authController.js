const User = require('../models/User');
const AuthService = require('../services/authService');
const AppError = require('../utils/appError');
const asyncHandler = require('../utils/asyncHandler');
const { env } = require('../config/env');

/**
 * Helper utility to attach refresh token inside an httpOnly cookie
 * and return access token in JSON body. This represents security best practices.
 */
const sendTokensResponse = (user, statusCode, res, message) => {
  const accessToken = AuthService.generateAccessToken(user);
  const refreshToken = AuthService.generateRefreshToken(user);

  const cookieOptions = {
    httpOnly: true, // Shields cookie from XSS scripts access
    secure: env === 'production', // Forces SSL encryption in production
    sameSite: 'strict', // Blocks CSRF cookie spoofing vectors
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days matching token expiration
  };

  res.cookie('refreshToken', refreshToken, cookieOptions);

  // Exclude password field from the return payload
  const userProfile = {
    id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone,
    address: user.address,
    createdAt: user.createdAt
  };

  res.status(statusCode).json({
    success: true,
    message,
    data: {
      accessToken,
      user: userProfile
    }
  });
};

/**
 * @desc    Registers a new user profile
 * @route   POST /api/v1/auth/signup
 * @access  Public
 */
exports.signup = asyncHandler(async (req, res, next) => {
  const { name, email, password, phone, role } = req.body;

  // 1. Assert email is unique before creation
  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) {
    return next(new AppError('A user profile already exists with this email address.', 409));
  }

  // 2. Safe register profile
  const user = await User.create({
    name,
    email,
    password,
    phone,
    role: role || 'customer' // Defaults securely to customer role
  });

  sendTokensResponse(user, 201, res, 'User registered successfully.');
});

/**
 * @desc    Authenticates credentials and issues sessions
 * @route   POST /api/v1/auth/login
 * @access  Public
 */
exports.login = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;

  // 1. Fetch user including password field for verification
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user) {
    return next(new AppError('Invalid email or password credentials.', 401));
  }

  // 2. Assert password authenticity
  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    return next(new AppError('Invalid email or password credentials.', 401));
  }

  sendTokensResponse(user, 200, res, 'Login successful.');
});

/**
 * @desc    Logs out current session by clearing secure cookies
 * @route   POST /api/v1/auth/logout
 * @access  Public
 */
exports.logout = asyncHandler(async (req, res, next) => {
  res.cookie('refreshToken', 'loggedout', {
    httpOnly: true,
    expires: new Date(Date.now() + 10 * 1000), // Expire in 10 seconds
    sameSite: 'strict',
    secure: env === 'production'
  });

  res.status(200).json({
    success: true,
    message: 'Logged out successfully. Session tokens cleared.'
  });
});

/**
 * @desc    Retrieves current user identity profile context
 * @route   GET /api/v1/auth/me/profile
 * @access  Private (Authenticated)
 */
exports.getProfile = asyncHandler(async (req, res, next) => {
  // req.user has already been loaded from database inside auth protect middleware
  const userProfile = {
    id: req.user._id,
    name: req.user.name,
    email: req.user.email,
    role: req.user.role,
    phone: req.user.phone,
    savedFavorites: req.user.savedFavorites,
    bookings: req.user.bookings,
    address: req.user.address,
    createdAt: req.user.createdAt
  };

  res.status(200).json({
    success: true,
    message: 'User profile fetched successfully.',
    data: {
      user: userProfile
    }
  });
});

/**
 * @desc    Refreshes access tokens using active secure httpOnly refresh cookie
 * @route   POST /api/v1/auth/refresh-token
 * @access  Public
 */
exports.refreshToken = asyncHandler(async (req, res, next) => {
  // Extract token dynamically from secure httpOnly cookies parsed by cookie-parser
  const token = req.cookies?.refreshToken || req.body?.refreshToken;

  if (!token || token === 'loggedout') {
    return next(new AppError('Token renewal failed: Missing refresh token.', 401));
  }

  try {
    // 1. Cryptographically verify the refresh token
    const decoded = AuthService.verifyRefreshToken(token);
    
    // 2. Fetch the target user profile
    const user = await User.findById(decoded.userId);
    if (!user) {
      return next(new AppError('Token renewal failed: Associated user no longer exists.', 401));
    }

    // 3. True Refresh Token Rotation (RTR): Generate new access token, sign a brand new
    // refresh token, and write it back to cookies to rotate the session locks dynamically.
    sendTokensResponse(user, 200, res, 'Token renewed successfully.');
  } catch (error) {
    // Clear cookie on invalid renewal attempts to reset client states safely
    res.clearCookie('refreshToken', {
      httpOnly: true,
      sameSite: 'strict',
      secure: env === 'production'
    });
    return next(new AppError('Token renewal failed: Invalid or expired refresh token. Cookies cleared.', 401));
  }
});
