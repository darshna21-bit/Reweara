const express = require('express');
const router = express.Router();
const outfitController = require('../controllers/outfitController');
const { protect, authorize } = require('../middleware/authMiddleware');
const { validateInput } = require('../middleware/validationMiddleware');

// 1. Public List Pathway
router.get('/', outfitController.getOutfits);

// 2. Administrative Control Pathways (Guarded under RBAC security filters)

router.post('/admin', protect, authorize('super_admin', 'admin'), validateInput('create_outfit'), outfitController.createOutfit);
router.patch('/admin/:id', protect, authorize('super_admin', 'admin'), validateInput('update_outfit'), outfitController.updateOutfit);
router.delete('/admin/:id', protect, authorize('super_admin', 'admin'), outfitController.deleteOutfit);

// 3. Dynamic Public Details Pathway (Must reside at the bottom to prevent route collisions)
router.get('/:slugOrId', outfitController.getOutfitDetails);

module.exports = router;
